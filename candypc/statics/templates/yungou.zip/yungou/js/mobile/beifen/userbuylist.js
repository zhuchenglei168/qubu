Base.getScript(Gobal.Skin+"/JS/mobile/UserBuyListFun.js?v=130826");
