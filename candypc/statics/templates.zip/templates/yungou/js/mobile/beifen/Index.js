alert(Gobal.Skin);
Base.getScript("http://127.0.0.1/yungou/statics/templates/yungou/js/mobile/IndexFun.js?v=130826");