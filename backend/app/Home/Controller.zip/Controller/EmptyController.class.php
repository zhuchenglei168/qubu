<?php
namespace Home\Controller;
use Think\Controller;
class EmptyController extends CommonController {}